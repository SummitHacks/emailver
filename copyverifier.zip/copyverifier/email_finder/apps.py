from django.apps import AppConfig


class EmailFinderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'email_finder'
